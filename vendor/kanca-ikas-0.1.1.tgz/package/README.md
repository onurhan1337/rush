# @kanca/ikas

Observability for [ikas](https://ikas.com) apps: webhook deliveries, Admin API
calls, installs/uninstalls and admin UI web vitals — shown in the
[Kanca](https://kanca.onurhan.dev) dashboard.

- **Metadata only.** Never payloads, variables, responses, headers or tokens.
- **Never breaks your app.** No throws, no added latency, responses untouched.
- Node 18+, Next.js App Router, any runtime with `fetch`/`Request`. No runtime
  dependencies on the server (`web-vitals` is used by the browser entry only).

```sh
pnpm add @kanca/ikas
```

## Environment

| Variable                       | Where         | Value                                |
| ------------------------------ | ------------- | ------------------------------------ |
| `KANCA_KEY`                    | backend only  | server key `kk_...`                  |
| `NEXT_PUBLIC_KANCA_PUBLIC_KEY` | browser       | public key `kp_...` (vitals only)    |

Without `KANCA_KEY` the SDK is a silent no-op, so local dev and CI need no setup.

## Integrate the ikas starter app (3 steps)

Create the client once — `src/lib/kanca.ts`:

```ts
import { createKanca } from '@kanca/ikas';
export const kanca = createKanca({ key: process.env.KANCA_KEY });
```

### 1. Webhooks — `src/app/api/webhooks/ikas/route.ts`

Wrap your route handler. Each delivery records scope, delivery id, merchant id,
your response status and duration. Subscribe to `store/app/deleted` to get
uninstalls for free.

```ts
import { kanca } from '@/lib/kanca';
import { validateIkasWebhookSignature, type IkasWebhook } from '@ikas/admin-api-client';
import { NextRequest, NextResponse } from 'next/server';

export const POST = kanca.webhook(async (request: NextRequest) => {
  const webhook = (await request.json()) as IkasWebhook; // body is still yours to read
  if (!validateIkasWebhookSignature(webhook, process.env.CLIENT_SECRET!)) {
    return NextResponse.json({ error: 'invalid signature' }, { status: 401 });
  }
  // ... handle webhook.scope
  return NextResponse.json({ ok: true }); // must be 200 — ikas retries anything else, even 201/204
});
```

### 2. Installs — `src/app/api/oauth/callback/ikas/route.ts`

After `await AuthTokenManager.put(token);`:

```ts
kanca.track('install', { merchantId, storeName: merchantResponse.data.getMerchant.storeName });
await kanca.flush();
```

### 3. Admin API calls — `src/helpers/api-helpers.ts`

Wrap the client in `getIkas()`:

```ts
export function getIkas(token: AuthToken) {
  return kanca.instrument(
    new ikasAdminGraphQLAPIClient<AuthToken>({
      graphApiUrl: config.graphApiUrl!,
      accessToken: token.accessToken,
      tokenData: token, // token.merchantId is attached to each call
      onCheckToken: () => onCheckToken(token),
    }),
  );
}
```

Every `ikas.queries.*` / `query()` / `mutate()` call becomes a `graphql` event
named after the operation (`getMerchant`, `listOrder`, …). A `200` response with
an `errors` array counts as a failure, with `errors[0].extensions.code` as the
error code.

`instrument()` works with `@ikas/admin-api-client` 2.x (any
`BaseGraphQLAPIClient` subclass) and survives token refreshes. For anything else
— your own GraphQL client, `graphql-request`, REST calls — use the drop-in
`kanca.fetch`:

```ts
const res = await kanca.fetch('https://api.myikas.com/api/v1/admin/graphql', { method: 'POST', headers, body });
```

ikas GraphQL URLs (`*.myikas.com/…graphql`) become `graphql` events; any other URL
becomes a `rest` event named `"POST api.example.com/v1/items"` (no query string).

Full example files: [`examples/starter-app`](./examples/starter-app).

## Admin UI web vitals

```tsx
// src/app/layout.tsx
import { KancaVitals } from '@kanca/ikas/react';

<body>
  <KancaVitals publicKey={process.env.NEXT_PUBLIC_KANCA_PUBLIC_KEY} />
  {children}
</body>;
```

Records LCP, INP, CLS, FCP and TTFB (final values, once per page load) with the
pathname and rating, sent with `fetch` + `keepalive` when the page is hidden
(`sendBeacon` only as a fallback — content blockers drop beacons silently).
Without React: `import { reportVitals } from '@kanca/ikas/browser'`.

## Serverless

Events are batched in memory and sent every 2 s (or at 100 events), and on
process exit. After each recorded event the SDK schedules a send without awaiting it.
On platforms that freeze the function after the response (Vercel, Lambda),
pass `waitUntil` so webhook, Admin API and install events all survive the freeze:

```ts
import { waitUntil } from '@vercel/functions';
export const kanca = createKanca({ key: process.env.KANCA_KEY, waitUntil });
```

or `await kanca.flush()` before returning (it never throws).

## Options

```ts
createKanca({
  key,                    // kk_...
  endpoint,               // default https://kanca.onurhan.dev
  debug,                  // log activity to the console
  disabled,               // force no-op
  flushIntervalMs,        // default 2000
  maxBatchSize,           // default 100, max 500
  maxQueueSize,           // default 5000; oldest events dropped beyond this
  waitUntil,              // (promise) => void
});
```

Failed sends are retried on 429/5xx/network errors (exponential backoff, 3
attempts). Every event has a UUID, so retries never double count.

## Privacy

What is sent: event type, name (webhook scope / GraphQL operation name /
`METHOD host/path`), HTTP status, ok, duration, error code, error message
(≤ 500 chars), merchant id, webhook delivery id, and for installs the store
name. Vitals send metric name, value, rating and pathname.

What is never sent: webhook bodies, the webhook signature, GraphQL queries,
variables or responses, request/response headers, access tokens, query strings,
customer or order data. Kanca never asks for your ikas client secret.

## Honest limits

- The SDK sees what reaches your app. Deliveries that never arrive (app down,
  DNS, TLS, timeouts before your handler runs) are invisible — the dashboard
  shows failures *seen by your app*.
- For `instrument()`, `@ikas/admin-api-client` does not expose the HTTP status
  of successful calls, so those events carry `ok: true` without a status. Use
  `kanca.fetch` if you need exact statuses.
- Events buffered in memory are lost if the process is killed hard (SIGKILL,
  OOM) before the next send.

## License

MIT
